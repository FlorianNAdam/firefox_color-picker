const colorPreview = document.createElement('div');
colorPreview.id = 'color-picker-preview';
Object.assign(colorPreview.style, {
    position: 'fixed',
    bottom: '10px',
    right: '10px',
    width: '40px',
    height: '40px',
    borderRadius: '50%',
    border: '2px solid #fff',
    boxShadow: '0 0 5px rgba(0,0,0,0.5)',
    pointerEvents: 'none',
    zIndex: '9999',
    backgroundColor: 'transparent'
});
document.body.appendChild(colorPreview);

document.addEventListener('mousemove', (e) => {
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el) return;

    const style = window.getComputedStyle(el);
    let bg = style.backgroundColor;

    // Convert rgba() to rgb() to ensure full opacity
    if (bg.startsWith('rgba')) {
        const parts = bg.match(/rgba\((\d+), (\d+), (\d+), ([\d.]+)\)/);
        if (parts) {
            const r = parts[1], g = parts[2], b = parts[3];
            bg = `rgb(${r}, ${g}, ${b})`;
        }
    }

    // If fully transparent, use a fallback (white)
    if (bg === 'transparent') bg = 'white';

    colorPreview.style.backgroundColor = bg;
});
